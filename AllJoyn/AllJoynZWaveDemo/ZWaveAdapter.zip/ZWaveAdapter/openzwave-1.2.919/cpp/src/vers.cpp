#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 2;
uint16_t ozw_vers_revision = 919;
