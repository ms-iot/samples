#include "pch.h"
#include "LSFHandler.h"
#include "MockLampConsts.h"
#include "MockLampDevice.h"
#include "MockAdapter.h"

using namespace AdapterLib;

LSFHandler::LSFHandler(MockLampDevice^ parentDevice)
    : m_parentDevice(parentDevice)
{
}


LSFHandler::~LSFHandler()
{
}


// LampService Interface
uint32 
LSFHandler::LampService_Version::get()
{
    return 1;
}


uint32 
LSFHandler::LampService_LampServiceVersion::get()
{
    return 1;
}


Platform::Array<uint32>^
LSFHandler::LampService_LampFaults::get()
{
    Platform::Array<uint32>^ lampFaults = ref new Platform::Array<uint32>(1);
    lampFaults[0] = 0;
    return lampFaults;
}


uint32 
LSFHandler::ClearLampFault(
    _In_ uint32 InLampFaultCode,
    _Out_ uint32 *LampResponseCode,
    _Out_ uint32 *OutLampFaultCode
    )
{
    *LampResponseCode = 0;
    *OutLampFaultCode = InLampFaultCode;
    return ERROR_SUCCESS;
}




// LampParameters Interface
uint32 
LSFHandler::LampParameters_Version::get()
{
    return 1;
}


uint32 
LSFHandler::LampParameters_EnergyUsageMilliwatts::get()
{
    return 0;
}


uint32 
LSFHandler::LampParameters_BrightnessLumens::get()
{
    return 0;
}




// LampDetails Interface
uint32 
LSFHandler::LampDetails_Version::get()
{
    return 1;
}


uint32 
LSFHandler::LampDetails_Make::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_Model::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_Type::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_LampType::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_LampBaseType::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_LampBeamAngle::get()
{
    return 0;
}


bool 
LSFHandler::LampDetails_Dimmable::get()
{
    return false;
}


bool 
LSFHandler::LampDetails_Color::get()
{
    return false;
}


bool 
LSFHandler::LampDetails_VariableColorTemp::get()
{
    return false;
}


bool 
LSFHandler::LampDetails_HasEffects::get()
{
    return false;
}


uint32 
LSFHandler::LampDetails_MinVoltage::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_MaxVoltage::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_Wattage::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_IncandescentEquivalent::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_MaxLumens::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_MinTemperature::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_MaxTemperature::get()
{
    return 0;
}


uint32 
LSFHandler::LampDetails_ColorRenderingIndex::get()
{
    return 0;
}


Platform::String^ 
LSFHandler::LampDetails_LampID::get()
{
    return LAMP_ID;
}




// LampState Interface
uint32 
LSFHandler::LampState_Version::get()
{
    return 1;
}


bool 
LSFHandler::LampState_OnOff::get()
{
    return m_parentDevice->LampState->IsOn;
}

void 
LSFHandler::LampState_OnOff::set(bool isOn)
{
    if (m_parentDevice->LampState->IsOn == isOn)
    {
        return;
    }

    m_parentDevice->LampState->IsOn = isOn;
    notifyLampStateChange();
}


uint32 
LSFHandler::LampState_Brightness::get()
{
    return m_parentDevice->LampState->Brightness;
}

void
LSFHandler::LampState_Brightness::set(uint32 brightness)
{
    if (m_parentDevice->LampState->Brightness == brightness)
    {
        return;
    }

    m_parentDevice->LampState->Brightness = brightness;
    notifyLampStateChange();
}


uint32 
LSFHandler::LampState_Hue::get()
{
    return m_parentDevice->LampState->Hue;
}

void 
LSFHandler::LampState_Hue::set(uint32 hue)
{
    if (m_parentDevice->LampState->Hue == hue)
    {
        return;
    }

    m_parentDevice->LampState->Hue = hue;
    notifyLampStateChange();
}


uint32 
LSFHandler::LampState_Saturation::get()
{
    return m_parentDevice->LampState->Saturation;
}

void
LSFHandler::LampState_Saturation::set(uint32 saturation)
{
    if (m_parentDevice->LampState->Saturation == saturation)
    {
        return;
    }

    m_parentDevice->LampState->Saturation = saturation;
    notifyLampStateChange();
}


uint32 
LSFHandler::LampState_ColorTemp::get()
{
    return m_parentDevice->LampState->ColorTemp;
}

void
LSFHandler::LampState_ColorTemp::set(uint32 colorTemp)
{
    if (m_parentDevice->LampState->ColorTemp == colorTemp)
    {
        return;
    }

    m_parentDevice->LampState->ColorTemp = colorTemp;
    notifyLampStateChange();
}


uint32 
LSFHandler::TransitionLampState(
    _In_ uint64 Timestamp,
    _In_ BridgeRT::State^ NewState,
    _In_ uint32 TransitionPeriod,
    _Out_ uint32 *LampResponseCode
    )
{
    UNREFERENCED_PARAMETER(Timestamp);
    UNREFERENCED_PARAMETER(TransitionPeriod);

    if (!isSameState(m_parentDevice->LampState, NewState))
    {
        m_parentDevice->LampState = NewState;
        notifyLampStateChange();
    }

    *LampResponseCode = 0;

    return ERROR_SUCCESS;
}


uint32 
LSFHandler::LampState_ApplyPulseEffect(
    _In_ BridgeRT::State^ FromState,
    _In_ BridgeRT::State^ ToState,
    _In_ uint32 Period,
    _In_ uint32 Duration,
    _In_ uint32 NumPulses,
    _In_ uint64 Timestamp,
    _Out_ uint32 *LampResponseCode
    )
{
    UNREFERENCED_PARAMETER(FromState);
    UNREFERENCED_PARAMETER(Period);
    UNREFERENCED_PARAMETER(Duration);
    UNREFERENCED_PARAMETER(NumPulses);
    UNREFERENCED_PARAMETER(Timestamp);

    if (!isSameState(m_parentDevice->LampState, ToState))
    {
        m_parentDevice->LampState = ToState;
        notifyLampStateChange();
    }

    *LampResponseCode = 0;

    return ERROR_SUCCESS;
}


BridgeRT::IAdapterSignal^ 
LSFHandler::LampState_LampStateChanged::get()
{
    return m_parentDevice->GetSignalByName(LAMP_STATE_CHANGED_SIGNAL_NAME);
}


void 
LSFHandler::notifyLampStateChange()
{
    MockAdapter^ adapter = dynamic_cast<MockAdapter^>(m_parentDevice->Parent);
    if (adapter == nullptr)
    {
        return;
    }

    MockAdapterSignal^ signal = m_parentDevice->GetSignalByName(LAMP_STATE_CHANGED_SIGNAL_NAME);
    if (signal == nullptr)
    {
        return;
    }

    adapter->NotifySignalListener(signal);
}


bool 
LSFHandler::isSameState(
    _In_ BridgeRT::State^ currentState,
    _In_ BridgeRT::State^ newState
    )
{
    if (currentState->IsOn != newState->IsOn ||
        currentState->Brightness != newState->Brightness ||
        currentState->Hue != newState->Hue ||
        currentState->Saturation != newState->Saturation ||
        currentState->ColorTemp != newState->ColorTemp
        )
    {
        return false;
    }

    return true;
}