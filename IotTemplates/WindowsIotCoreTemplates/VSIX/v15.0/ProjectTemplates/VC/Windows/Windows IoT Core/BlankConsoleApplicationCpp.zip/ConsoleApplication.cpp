// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "pch.h"

int main(int argc, char **argv)
{
    std::cout << "Hello, World!" << std::endl;
}
