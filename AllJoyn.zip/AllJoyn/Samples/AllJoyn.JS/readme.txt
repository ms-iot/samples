Subfolders contain sources from Allseen Alliance Git Release 15.04
1. ajtcl - https://git.allseenalliance.org/cgit/core/ajtcl.git
2. alljoyn-js - https://git.allseenalliance.org/cgit/core/alljoyn-js.git
3. base_tcl - https://git.allseenalliance.org/cgit/services/base_tcl.git
4. duktape - http://duktape.org/snapshots/duktape-master.tar.xz

Branch:
1. checkout branch RB15.04 (git checkout RB15.04)

Folder structure:
External
   | ---- allseen
   |         | ---- core
   |         |       | ---- ajtcl
   |         |       | ---- alljoyn-js
   |         |
   |         | ---- services
   |                 | ---- base_tcl
   |
   | ---- duktape
   
Reference:
1. https://allseenalliance.org/framework/documentation/develop/building/alljoyn-js
